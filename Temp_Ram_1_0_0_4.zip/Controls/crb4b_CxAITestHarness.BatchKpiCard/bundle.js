/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./BatchKpiCard/index.ts"
/*!*******************************!*\
  !*** ./BatchKpiCard/index.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   BatchKpiCard: () => (/* binding */ BatchKpiCard)\n/* harmony export */ });\nclass BatchKpiCard {\n  constructor() {\n    // Empty\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this.container = container;\n    var card = document.createElement(\"div\");\n    card.className = \"kpi-card\";\n    var stats = document.createElement(\"div\");\n    stats.className = \"kpi-stats\";\n    var totalBox = this.buildStatBox(\"kpi-stat-total\", \"TOTAL\");\n    this.totalValueEl = totalBox.valueEl;\n    var passBox = this.buildStatBox(\"kpi-stat-pass\", \"PASS\");\n    this.passValueEl = passBox.valueEl;\n    var failBox = this.buildStatBox(\"kpi-stat-fail\", \"FAIL\");\n    this.failValueEl = failBox.valueEl;\n    stats.appendChild(totalBox.box);\n    stats.appendChild(passBox.box);\n    stats.appendChild(failBox.box);\n    var rateRow = document.createElement(\"div\");\n    rateRow.className = \"kpi-rate-row\";\n    var rateLabel = document.createElement(\"div\");\n    rateLabel.className = \"kpi-rate-label\";\n    rateLabel.textContent = \"PASS RATE\";\n    var barTrack = document.createElement(\"div\");\n    barTrack.className = \"kpi-bar-track\";\n    this.barFillEl = document.createElement(\"div\");\n    this.barFillEl.className = \"kpi-bar-fill\";\n    barTrack.appendChild(this.barFillEl);\n    this.rateValueEl = document.createElement(\"span\");\n    this.rateValueEl.className = \"kpi-rate-value\";\n    rateRow.appendChild(rateLabel);\n    rateRow.appendChild(barTrack);\n    rateRow.appendChild(this.rateValueEl);\n    card.appendChild(stats);\n    card.appendChild(rateRow);\n    this.container.appendChild(card);\n  }\n  buildStatBox(cssClass, label) {\n    var box = document.createElement(\"div\");\n    box.className = \"kpi-stat \" + cssClass;\n    var valueEl = document.createElement(\"span\");\n    valueEl.className = \"kpi-stat-value\";\n    valueEl.textContent = \"-\";\n    var labelEl = document.createElement(\"span\");\n    labelEl.className = \"kpi-stat-label\";\n    labelEl.textContent = label;\n    box.appendChild(valueEl);\n    box.appendChild(labelEl);\n    return {\n      box,\n      valueEl\n    };\n  }\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h;\n    var total = (_b = (_a = context.parameters.totalCount) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : null;\n    var pass = (_d = (_c = context.parameters.passCount) === null || _c === void 0 ? void 0 : _c.raw) !== null && _d !== void 0 ? _d : null;\n    var fail = (_f = (_e = context.parameters.failCount) === null || _e === void 0 ? void 0 : _e.raw) !== null && _f !== void 0 ? _f : null;\n    var rate = (_h = (_g = context.parameters.passRate) === null || _g === void 0 ? void 0 : _g.raw) !== null && _h !== void 0 ? _h : null;\n    this.totalValueEl.textContent = total === null ? \"-\" : String(total);\n    this.passValueEl.textContent = pass === null ? \"-\" : String(pass);\n    this.failValueEl.textContent = fail === null ? \"-\" : String(fail);\n    var rateNum = rate === null ? 0 : rate;\n    this.rateValueEl.textContent = rate === null ? \"-\" : \"\".concat(rateNum, \"%\");\n    this.barFillEl.style.width = \"\".concat(Math.max(0, Math.min(100, rateNum)), \"%\");\n    this.barFillEl.classList.remove(\"kpi-bar-red\", \"kpi-bar-amber\", \"kpi-bar-green\");\n    if (rateNum >= 80) {\n      this.barFillEl.classList.add(\"kpi-bar-green\");\n    } else if (rateNum >= 50) {\n      this.barFillEl.classList.add(\"kpi-bar-amber\");\n    } else {\n      this.barFillEl.classList.add(\"kpi-bar-red\");\n    }\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // No listeners registered - nothing to clean up.\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./BatchKpiCard/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = {};
/******/ 	__webpack_modules__["./BatchKpiCard/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('CxAITestHarness.BatchKpiCard', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.BatchKpiCard);
} else {
	var CxAITestHarness = CxAITestHarness || {};
	CxAITestHarness.BatchKpiCard = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.BatchKpiCard;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}